class SharedStrign {
  static const String isFirstTime = 'isFirstTime';
  static const String jwt = 'JWT';
  static const String kofahi = 'kofahi';
}